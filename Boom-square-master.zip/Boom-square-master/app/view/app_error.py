#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2018-02-26 17:10:50
# @Author  : Job (Job@6box.net)
# @Link    : http://www.6box.net
# @Version : $Id$


def err_create(request):
    return render(request, 'create.html')


def err_edit(request):
    return render(request, 'create.html')


def err_delete(request):
    return render(request, 'create.html')
