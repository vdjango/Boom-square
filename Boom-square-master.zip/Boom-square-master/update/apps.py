from django.apps import AppConfig


class UpdateConfig(AppConfig):
    name = 'update'
