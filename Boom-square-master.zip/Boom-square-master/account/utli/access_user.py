#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2018-02-08 19:01:38
# @Author  : Job (Job@6box.net)
# @Link    : http://www.6box.net
# @Version : $Id$


def auth_MD5():
    pass


def auth_user():
    return False
