from django.db import models
import json
# Create your models here.


def function():
    pass
